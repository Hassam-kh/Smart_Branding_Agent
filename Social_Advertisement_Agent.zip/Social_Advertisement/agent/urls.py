from django.contrib import admin
from django.urls import path
from agent import views

urlpatterns = [
    path("", views.index,name="login"),
    path("signup", views.signup,name="signup"),
    path("home", views.home,name="home"),
    path("info", views.info,name="info"),
    path("processed_home", views.processed_home,name="processed_home"),
]
