import os
file_path = 'C:\\Users\\dortemon\\Downloads\\Advertisement_APP\\env.txt'

# Bing Image Creator API Key
with open(file_path, 'r') as file:
    text_content = file.read()
u_cookie_api=text_content

def generate_images(prompt):
    command=f'python -m BingImageCreator --prompt "{prompt}" -U "{u_cookie_api}"'
    os.system(command)
    return os.listdir("output")
