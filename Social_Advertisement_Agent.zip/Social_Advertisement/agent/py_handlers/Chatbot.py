from langchain.callbacks.manager import CallbackManager
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.chains import LLMChain
from langchain.llms import LlamaCpp
from langchain.prompts import PromptTemplate
from django.http import JsonResponse
# Callbacks support token-wise streaming
# callback_manager = CallbackManager([])
callback_manager = CallbackManager([StreamingStdOutCallbackHandler()])

def get_prompt(instruction_prompt=None, system_prompt=None):
    Begin_Instruction, End_Instruction = "[INST]", "[/INST]"
    Begin_System, End_System = "<<SYS>>\n", "\n<</SYS>>\n\n"
    if system_prompt is None:
        system_prompt = """\
        You are a powerful Social Media Marketing model. You help companies in content marketing. When user gives there company details, generate a response related to that text by looking at context.
        Strictly follow the instructions and output format. Output response only.
        """

    if instruction_prompt is None:
        instruction_prompt = "{user_input}"
    SYSTEM_PROMPT = Begin_System + system_prompt + End_System
    prompt_template =  Begin_Instruction + SYSTEM_PROMPT + instruction_prompt + End_Instruction
    return prompt_template

def prompt_template():
    template = get_prompt()
    prompt = PromptTemplate(input_variables=["user_input"], template=template)
    return prompt

llm = LlamaCpp(
    model_path="C:\\Users\\dortemon\\Downloads\\Advertisement_APP\\llama-2-7b-chat.gguf.q8_0.bin",
    temperature=0.75,
    max_tokens=2000,
    top_p=1,
    callback_manager=callback_manager,
    verbose=True,  # Verbose is required to pass to the callback manager
)
def chain():
    prompt = prompt_template()
    llm_chain = LLMChain(llm=llm, prompt=prompt, verbose=False)
    return llm_chain
bot=chain()
def answer(q,context):
    prompt=f"""You are a powerful marketing model. Your job is to generate response given a company name, the industry which the company is working in and 
            the companies Unique Selling Point (USP). Don't be bias or offensive. Try to write response Professionally and attractive. You must only output the answer of asked question, nothing extra is needed.
            Do not give any additional information. write '\n' for next line

            ### Input:
            {q}

            ### Context:
            {context}

            ### Response:
            """
    response=bot.predict(user_input=prompt)
    return response
