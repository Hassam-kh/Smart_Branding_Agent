import os
import shutil
def delt_files(path):
    pth=os.getcwd()
    folder_path = pth+ path #'\\agent\\static\\output'
    files = os.listdir(folder_path)
    for file in files:
        file_path = os.path.join(folder_path, file)
        try:
            os.remove(file_path)
        except Exception as e:
            print(f"Error deleting: {e}")
    print("Done")
def copy_files(path1,path2):
    pth=os.getcwd()
    source_folder=pth+path1
    destination_folder=pth+path2
    all_files = os.listdir(source_folder)
    image_files = [file for file in all_files if file.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
    for image_file in image_files:
        try:
            source_path = os.path.join(source_folder, image_file)
            destination_path = os.path.join(destination_folder, image_file)
            shutil.move(source_path, destination_path)
        except:
            print("Corrupt File")
    print("Done")