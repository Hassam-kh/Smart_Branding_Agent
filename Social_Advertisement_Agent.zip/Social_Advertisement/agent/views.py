from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from .forms import CompanyForm
from django.core.cache import cache
from .threads import responsethread
import os
import asyncio
from .py_handlers.fun import delt_files,copy_files
# Create your views here.


def index(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('pass')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            # Log the user in
            login(request, user)
            return redirect('info')
        else:
            error_message = 'Invalid username or password. Please try again.'
            return render(request, 'index.html', {'error_message': error_message})

    return render(request, 'index.html')

edd=None
def processed_home(request):
    global edd
    edd.join()
    letter_head,media_post,profile=edd.get_result()
    form_data = request.session.get('company_form_data', None)
    copy_files("\\output","\\agent\\static\\output")
    pth=os.getcwd()
    image_files = os.listdir(pth+"\\agent\\static\\output")
    image_urls = [os.path.join(pth+'\\agent\\static\\output', image_file).replace("\\", "/") for image_file in image_files]
    print(image_urls)
    return render(request, 'home.html', {'image_urls': image_urls[:2],'brand':form_data['name'].upper(),'dynamic_text1': letter_head,'dynamic_text2': media_post,'dynamic_text3': profile})
def home(request):
    global edd
    form_data = request.session.get('company_form_data', None)
    edd=responsethread(form_data['name'],form_data['industry'],form_data['details'])
    edd.start()
    result="Thank you for your patience. We are currently processing your request. "
    return render(request, 'home.html', {'msg':"Processing, This might take some time.",'brand':form_data['name'].upper(),'dynamic_text1': result,'dynamic_text2': result,'dynamic_text3': result,'redirected':"True"})


def info(request):
    if request.method == 'POST':
        delt_files("\\output")
        form = CompanyForm(request.POST)
        if form.is_valid():
            request.session['company_form_data'] = form.cleaned_data
            form.save()
            return redirect('home')
        else:
            print(form.errors)  # Redirect to a success page
    else:
        form = CompanyForm()

    return render(request, 'info.html', {'form': form})


def signup(request):
    if request.method == 'POST':
        username = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('pass')
        repass = request.POST.get('re_pass')
        agree_term = request.POST.get('agree-term')
        if username != '' and email != '' and password != '' and repass != '' and agree_term:
            if User.objects.filter(username=username).exists():
                error_message = 'Username already exists. Please choose a different username.'
                return render(request, 'Signup.html', {'error_message': error_message})
            if password != repass:
                error_message = 'Password Does Not Match.'
                return render(request, 'Signup.html', {'error_message': error_message})
            user = User.objects.create_user(username, email, password)
            user.save()
            return redirect('login')
        else:
            error_message = 'Kindly Fill Out The Information.'
            return render(request, 'Signup.html', {'error_message': error_message})
    return render(request, 'Signup.html')
