from collections.abc import Callable, Iterable, Mapping
import threading
from typing import Any
from .py_handlers.Chatbot import answer
from .py_handlers.image_gen import generate_images

class responsethread(threading.Thread):
    def __init__(self,name,industry,details):
        threading.Thread.__init__(self)
        self.name=name
        self.industry=industry
        self.details=details
        self.result1 = None
        self.result2 = None
        self.result3 = None 
        
    def run(self):
        try:
            context=f"Company name is {self.name}, the industry which our company currently works in is {self.industry} and our unique selling point (USP) is {self.details}"
            letter_head="Write a Letter Head of my company."
            self.result1 =answer(letter_head,context)
            post="Write Instagram Post of my company for advertisement."
            self.result2 =answer(post,context)
            profile="write a profile of my company."
            self.result3 =answer(profile,context)
            generate_images(f"Create a Logo of my company. {context}")
        except:
            print("Error processing message")
    def get_result(self):
        return self.result1,self.result2,self.result3